##########################################################################################
# Machine Environment Config

DEBUG_MODE = False
USE_CUDA = not DEBUG_MODE
CUDA_DEVICE_NUM = 5

##########################################################################################
# Path Config

import os
import sys
import numpy as np

os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "..")  # for problem_def
sys.path.insert(0, "../..")  # for utils

##########################################################################################
# import

import logging
from utils.utils import create_logger, copy_all_src
from TSP.Test_All.TSPTester_draw import TSPTester as Tester
import matplotlib.pyplot as plt
from datetime import datetime

##########################################################################################
# parameters

b = os.path.abspath(".").replace('\\', '/')
b2 = os.path.abspath("..").replace('\\', '/')

env_params = {
    'pomo_size': 1,
    'k_nearest': 1,
    'beam_width': 16,
    'decode_method': 'greedy',
    'mode': 'test',
    'test_in_tsplib': False,
    'tsplib_path': None,
    'data_path': None,
    'load_way': 'allin',
    'sub_path': False,
    'budget': 10,
    'PRC': True,
    'repair_max_sub_length': 1000,
    'random_insertion': False
}

model_params = {
    'mode': 'test',
    'embedding_dim': 128,
    'sqrt_embedding_dim': 128 ** (1 / 2),
    'encoder_layer_num': 6,
    'qkv_dim': 16,
    'head_num': 8,
    'logit_clipping': 10,
    'ff_hidden_dim': 512,
    'eval_type': 'argmax',
    'use_k_nearest': True,
    'k_nearest_num': 1000
}

tester_params = {
    'use_cuda': USE_CUDA,
    'cuda_device_num': CUDA_DEVICE_NUM,
    'model_load': {'path': None},
    'test_episodes': 16,
    'test_batch_size': 4,
}

logger_params = {
    'log_file': {
        'desc': 'test__uniform1k_greedy',
        'filename': 'log.txt'
    }
}

##########################################################################################
# 绘图函数：完全仿照 save_plot 风格
def save_plot(points, path=None, file_path="output.pdf"):
    fig, ax = plt.subplots(figsize=(6, 6))
    point_size = 60  # 固定点大小
    ax.scatter(points[:, 0], points[:, 1],
               s=point_size,
               c="#007acc",
               edgecolors="#007acc",  # 点边框与填充颜色一致
               linewidths=1.2)
    if path is not None:
        path_coords = np.vstack([points[path], points[path[0]]])  # 闭合路径
        ax.plot(path_coords[:, 0], path_coords[:, 1],
                c="#ff6600", lw=4.0, alpha=0.9)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_linewidth(1.2)
        spine.set_visible(True)
    ax.set_xlim(-0.05, 1.05)
    ax.set_ylim(-0.05, 1.05)

    # -------------------------
    # 保存 PDF 与 SVG
    # -------------------------
    plt.savefig(file_path, bbox_inches="tight")
    svg_path = file_path.replace(".pdf", ".svg")
    plt.savefig(svg_path, bbox_inches="tight")
    plt.close()
    print(f"✅ 已保存: {file_path}")
    print(f"✅ 已保存: {svg_path}")


##########################################################################################
# main_test 函数

def main_test(path, prob_size, PRC, repair_max_sub_length, budget, random_insertion):
    logger_params['log_file']['desc'] = f'test_{prob_size}_RandomInsertion_{random_insertion}_PRC_{PRC}'

    create_logger(**logger_params)
    tester_params['model_load'] = {'path': path}

    tester_params['test_episodes'] = datas[prob_size][1]
    tester_params['test_batch_size'] = datas[prob_size][2]
    env_params['data_path'] = b2 + datas[prob_size][0]
    env_params['PRC'] = PRC
    env_params['repair_max_sub_length'] = repair_max_sub_length
    env_params['budget'] = budget
    env_params['random_insertion'] = random_insertion

    if prob_size == -1:
        env_params['test_in_tsplib'] = True
        env_params['tsplib_path'] = b2 + datas[prob_size][0]
        env_params['data_path'] = b2 + datas[prob_size][0]

    if not random_insertion and budget == 0:
        model_params['use_k_nearest'] = False

    _print_config()
    tester = Tester(env_params=env_params,
                    model_params=model_params,
                    tester_params=tester_params)
    copy_all_src(tester.result_folder)

    score_optimal, score_student, gap, coords_list, paths_list = tester.run()
    return score_optimal, score_student, gap, coords_list, paths_list

##########################################################################################
# _print_config

def _print_config():
    logger = logging.getLogger('root')
    logger.info(f'DEBUG_MODE: {DEBUG_MODE}')
    logger.info(f'USE_CUDA: {USE_CUDA}, CUDA_DEVICE_NUM: {CUDA_DEVICE_NUM}')
    [logger.info(g_key + "{}".format(globals()[g_key])) for g_key in globals().keys() if g_key.endswith('params')]

##########################################################################################
# 主程序

if __name__ == "__main__":
    datas = {
        # 1000: ['/data/test_set/test_tsp100_concorde_n10000_first5.txt', 5, 5],
        1000: ['/data/test_set/MCTS_tsp1000_test_concorde.txt', 5, 5],
        5000: ['/data/test_set/test_tsp5000_lkh3_n16.txt', 16, 16],
        10000: ['/data/test_set/MCTS_tsp10000_test_concorde.txt', 16, 16],
        50000: ['/data/test_set/test_tsp50000_lkh3_n16.txt', 16, 8],
        100000: ['/data/test_set/test_tsp100000_lkh3_n16.txt', 16, 4],
        -1: ["/data/test_set/TSPlib_scale_ge_1K_n33_ascending.txt", 33, 1, 0]
    }

    model_path = {
        1000: './result/checkpoint-tsp1k.pt',
        5000: './result/checkpoint-tsp5k.pt',
        10000: './result/checkpoint-tsp10k.pt',
        50000: './result/checkpoint-tsp50k.pt',
        100000: './result/checkpoint-tsp100k.pt',
        -1: './result/checkpoint-tsp1k.pt',
    }

    PRC = True
    repair_max_sub_length = 1000
    random_insertion = True
    budget_list = [500]

    for prob_size in [1000]:
        for budget in budget_list:
            score_optimal, score_student, gap, coords_list, paths_list = main_test(
                model_path[prob_size],
                prob_size,
                PRC,
                repair_max_sub_length,
                budget,
                random_insertion
            )

            coords = coords_list[0][0].numpy()
            path = paths_list[0][0].numpy()

            base_dir = os.path.dirname(os.path.abspath(__file__))
            time_tag = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            save_dir = os.path.join(base_dir, "output_draw", time_tag)
            os.makedirs(save_dir, exist_ok=True)

            # 图1：点图（无连线）
            path_points = os.path.join(save_dir, f"TSP_{prob_size}_budget{budget}_points.pdf")
            save_plot(coords, path=None, file_path=path_points)

            # 图2：路径图（带连线）
            path_full = os.path.join(save_dir, f"TSP_{prob_size}_budget{budget}_path.pdf")
            save_plot(coords, path=path, file_path=path_full)
