import json
import numpy as np
from typing import List, Dict, Tuple
import time

# -------------------------
# 根据规模返回默认 window
# -------------------------
def get_window_by_scale(n: int) -> int:
    if n <= 1000:
        return 300
    elif n <= 5000:
        return 400
    elif n <= 10000:
        return 500
    elif n <= 50000:
        return 800
    else:
        return 1000

# -------------------------
# 从 JSON 加载启发式 score 函数
# -------------------------
def load_heuristic_from_json(json_path: str):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    code_str = data['code']
    local_vars = {}
    exec(code_str, globals(), local_vars)
    if 'score' not in local_vars:
        raise ValueError("启发式json中未包含score函数")
    return local_vars['score']

# -------------------------
# 构建候选边
# -------------------------
def build_candidate_edges(coord: List[List[float]], score_func, tour: List[int],
                          k: int = 20, window: int = None) -> Dict[int, List[int]]:
    coords_np = np.array(coord)
    n = len(tour)
    candidate_edges = {}

    # 支持外部传入 window
    if window is None:
        window = get_window_by_scale(n)

    for i in range(n):
        current_node_idx = tour[i]
        current_node = coords_np[current_node_idx]

        neighbor_indices = []
        for offset in range(-window, window + 1):
            if offset == 0:
                continue
            j = (i + offset) % n
            neighbor_indices.append(tour[j])

        if not neighbor_indices:
            candidate_edges[current_node_idx] = []
            continue

        neighbor_coords = coords_np[neighbor_indices]
        scores = score_func(current_node, neighbor_coords)

        top_k_idx = np.argsort(scores)[::-1][:k]
        top_k_nodes = [neighbor_indices[idx] for idx in top_k_idx]

        candidate_edges[current_node_idx] = top_k_nodes

    return candidate_edges

# -------------------------
# 2-opt 优化
# -------------------------
def twoopt(candidate_edges: Dict[int, List[int]], tour: List[int], coord: List[List[float]], max_iter: int = 50) -> Tuple[List[int], float]:
    def path_length(path: List[int], coord: List[List[float]]) -> float:
        length = 0.0
        n = len(path)
        for i in range(n - 1):
            a, b = path[i], path[i + 1]
            dx = coord[a][0] - coord[b][0]
            dy = coord[a][1] - coord[b][1]
            length += np.sqrt(dx * dx + dy * dy)
        dx = coord[path[-1]][0] - coord[path[0]][0]
        dy = coord[path[-1]][1] - coord[path[0]][1]
        length += np.sqrt(dx * dx + dy * dy)
        return length

    path = tour[:]
    n = len(path)

    improved = True
    iter_count = 0
    start_time = time.time()

    while improved and iter_count < max_iter:
        start_iter_time = time.time()
        improved = False
        iter_count += 1

        for i in range(n - 1):
            node_i = path[i]
            node_i1 = path[i + 1]

            for neighbor in candidate_edges.get(node_i, []):
                j = path.index(neighbor)
                if j <= i + 1 or j == n - 1:
                    continue

                node_j = path[j]

                dist_before = np.linalg.norm(np.array(coord[node_i]) - np.array(coord[node_i1])) + \
                              np.linalg.norm(np.array(coord[node_j]) - np.array(coord[path[(j + 1) % n]]))
                dist_after = np.linalg.norm(np.array(coord[node_i]) - np.array(coord[node_j])) + \
                             np.linalg.norm(np.array(coord[node_i1]) - np.array(coord[path[(j + 1) % n]]))

                delta = dist_after - dist_before

                if delta < -1e-9:
                    path[i + 1:j + 1] = reversed(path[i + 1:j + 1])
                    improved = True
                    break
            if improved:
                break

        end_iter_time = time.time()
        total_elapsed = end_iter_time - start_time

        if iter_count % 10 == 0:
            print(f"第 {iter_count} 轮耗时: {end_iter_time - start_iter_time:.4f} 秒")
            print(f"当前总耗时: {total_elapsed:.4f} 秒")

        if total_elapsed > 1800:
            print(f"[警告] 累计耗时 {total_elapsed:.2f} 秒，超过 1800 秒，提前终止。")
            break
        iter_elapsed = end_iter_time - start_iter_time
        if iter_elapsed > 180:
            print(f"[警告] 第 {iter_count} 轮耗时 {iter_elapsed:.2f} 秒，超过3分钟，提前终止。")
            break

    final_length = path_length(path, coord)
    return path, final_length

# -------------------------
# 主函数：支持外部传入 k、max_iter、window
# -------------------------
def heuristic_optimize_from_json(tour: List[int], coord: List[List[float]], json_path: str,
                                 k: int = None, max_iter: int = None, window: int = None) -> Tuple[List[int], float]:
    n = len(tour)

    if max_iter is None:
        max_iter = 50

    if k is None:
        if n <= 1000:
            k = 50
        elif n <= 5000:
            k = 50
        elif n <= 10000:
            k = 50
        elif n <= 50000:
            k = 20
        else:
            k = 20

    if window is None:
        window = get_window_by_scale(n)

    print(f"[INFO] 使用参数 -> k: {k}, max_iter: {max_iter}, window: {window}")

    score_func = load_heuristic_from_json(json_path)
    start_build = time.time()
    candidate_edges = build_candidate_edges(coord, score_func, tour, k, window)
    end_build = time.time()

    print(f"[INFO] 构建候选边耗时: {end_build - start_build:.4f} 秒")

    start_opt = time.time()
    optimized_path, length = twoopt(candidate_edges, tour, coord, max_iter)
    end_opt = time.time()
    print(f"[INFO] 2-opt 优化耗时: {end_opt - start_opt:.4f} 秒")

    return optimized_path, length
