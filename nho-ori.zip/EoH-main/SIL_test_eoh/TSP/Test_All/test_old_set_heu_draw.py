import os
import sys
# Setup path
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "..")
sys.path.insert(0, "../..")
import torch
import logging
import numpy as np
from utils.utils import create_logger, copy_all_src
from TSP.Test_All.TSPTester_save_drawnew import TSPTester as Tester
from heuristic_optimize_draw import heuristic_optimize_from_json
import datetime  # 用于时间戳
import matplotlib.pyplot as plt  # 新增绘图
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['font.family'] = 'STIXGeneral'
plt.rcParams['font.size'] = 30             # 全局字体大小（标题、坐标轴、刻度、legend 全部一起变大）
plt.rcParams['axes.titlesize'] = 30        # 图标题字体大小
plt.rcParams['axes.labelsize'] = 30        # 坐标轴 X/Y 标签字体
plt.rcParams['xtick.labelsize'] = 30       # X 轴刻度
plt.rcParams['ytick.labelsize'] = 30       # Y 轴刻度
plt.rcParams['legend.fontsize'] = 20       # 图例字体


# 机器环境配置
DEBUG_MODE = False
USE_CUDA = not DEBUG_MODE
CUDA_DEVICE_NUM = 1

logger_params = {
    'log_file': {
        'desc': 'test_param_matrix',
        'filename': 'log.txt'
    }
}

env_params = {
    'pomo_size': 1,
    'k_nearest': 1,
    'beam_width': 16,
    'decode_method': 'greedy',
    'mode': 'test',
    'test_in_tsplib': False,
    'tsplib_path': None,
    'data_path': None,
    'load_way': 'allin',
    'sub_path': False,
    'budget': None,
    'PRC': True,
    'repair_max_sub_length': 1000,
    'random_insertion': True,
}

model_params = {
    'mode': 'test',
    'embedding_dim': 128,
    'sqrt_embedding_dim': 128 ** 0.5,
    'encoder_layer_num': 6,
    'qkv_dim': 16,
    'head_num': 8,
    'logit_clipping': 10,
    'ff_hidden_dim': 512,
    'eval_type': 'argmax',
    'use_k_nearest': True,
    'k_nearest_num': 1000,
}

tester_params = {
    'use_cuda': USE_CUDA,
    'cuda_device_num': CUDA_DEVICE_NUM,
    'model_load': {'path': None},
    'test_episodes': 128,
    'test_batch_size': 128,
}

b2 = os.path.abspath("..").replace('\\', '/')
datas = {
        1000: ['/data/test_set/MCTS_tsp1000_test_concorde.txt', 128, 128],
        5000: ['/data/test_set/test_tsp5000_lkh3_n16.txt', 16, 16],
        10000: ['/data/test_set/MCTS_tsp10000_test_concorde.txt', 16, 16],
        50000: ['/data/test_set/test_tsp50000_lkh3_n16.txt', 16, 8],
        100000: ['/data/test_set/test_tsp100000_lkh3_n16.txt', 16, 4],
        1748: ['/data/test_set/tsplib_14th_solo.txt', 1, 1],
        -1:["/data/test_set/14th_line.txt", 1, 1, 0]
    }

model_path = {
    1000:   './result/checkpoint-tsp1k.pt',
    1748:   './result/checkpoint-tsp1k.pt',
    5000:   './result/checkpoint-tsp5k.pt',
    10000:  './result/checkpoint-tsp10k.pt',
    50000:  './result/checkpoint-tsp50k.pt',
    100000: './result/checkpoint-tsp100k.pt',
    -1:     './result/checkpoint-tsp1k.pt',
}


def plot_paths(coords, path, title, save_path):
    coords = np.array(coords)
    path = np.array(path)

    # ---- 关键补充：将路径闭合 ----
    closed_path = np.append(path, path[0])
    ordered_coords = coords[closed_path]

    plt.figure(figsize=(6, 6))

    # 画路径
    plt.plot(ordered_coords[:, 0], ordered_coords[:, 1], '-', color='blue', linewidth=2)

    # 节点
    plt.scatter(coords[:, 0], coords[:, 1], c='red', s=10)

    plt.title(title)
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.axis('equal')
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()

def plot_integrated_improvement(coords, initial_path, best_path, opt_path, save_path, len_c, len_f):
    import numpy as np
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    coords = np.array(coords)

    # -----------------------------------------------------
    # 新增：计算 π0、πc、πf 的路径长度
    # -----------------------------------------------------
    def path_length(path, coords):
        p = np.array(path)
        p_close = np.append(p, p[0])
        xy = coords[p_close]
        return np.sum(np.sqrt(np.sum((xy[1:] - xy[:-1]) ** 2, axis=1)))

    len0 = path_length(initial_path, coords)  # π0

    # πc 与 πf 的数值由外部传入，因此由调用者提供
    # 为保持函数独立，下面两个值在主程序中传入
    # -------------------------
    # 辅助函数：从路径生成边集合
    # -------------------------
    def edges_from_path(path):
        path = np.array(path)
        closed = np.append(path, path[0])
        return set((int(closed[i]), int(closed[i+1])) for i in range(len(path)))

    def normalize_edge(e):
        return (min(e[0], e[1]), max(e[0], e[1]))

    # 三阶段边集合
    E0 = set(normalize_edge(e) for e in edges_from_path(initial_path))
    E1 = set(normalize_edge(e) for e in edges_from_path(best_path))
    E2 = set(normalize_edge(e) for e in edges_from_path(opt_path))

    changed_1 = (E1 - E0)   # 初始→神经模型
    changed_2 = (E2 - E1)   # 神经模型→启发式

    # ============================================================
    #                     主图
    # ============================================================
    fig, ax = plt.subplots(figsize=(7, 7))

    # 样式定义
    style_initial = {'color': 'dimgray', 'linewidth': 0.5, 'linestyle': '-'}
    style_neural   = {'color': 'blue', 'linewidth': 1, 'linestyle': (0, (1,1))}  # 蓝色改虚线
    style_heuristic = {'color': 'red', 'linewidth': 2, 'linestyle': '-'}

    # 绘制主图边
    for u, v in E0: ax.plot([coords[u][0], coords[v][0]], [coords[u][1], coords[v][1]], **style_initial)
    for u, v in changed_1: ax.plot([coords[u][0], coords[v][0]], [coords[u][1], coords[v][1]], **style_neural)
    for u, v in changed_2: ax.plot([coords[u][0], coords[v][0]], [coords[u][1], coords[v][1]], **style_heuristic)

    # 节点
    ax.scatter(coords[:, 0], coords[:, 1], s=1, color='black')

    ax.set_title(
        f"TSP10K, $N_d$=10\n"
        f"$\\pi_0$ ({len0:.2f}) → $\\pi_c$ ({len_c:.2f}) → $\\pi_f$ ({len_f:.2f})"
    )

    ax.set_aspect('equal', adjustable='box')

    # 九宫格线
    grid_x = [0.0, 1/3, 2/3, 1.0]
    grid_y = [0.0, 1/3, 2/3, 1.0]
    for gx in grid_x: ax.plot([gx, gx], [0,1], color='black', linestyle='--', linewidth=0.8)
    for gy in grid_y: ax.plot([0,1], [gy, gy], color='black', linestyle='--', linewidth=0.8)

    # 确保 axis 至少包含 [0,1]
    cur_xmin, cur_xmax = ax.get_xlim()
    cur_ymin, cur_ymax = ax.get_ylim()
    ax.set_xlim(min(cur_xmin,0), max(cur_xmax,1))
    ax.set_ylim(min(cur_ymin,0), max(cur_ymax,1))

    # legend
    legend_handles = [
        Line2D([0],[0], color=style_initial['color'], linewidth=style_initial['linewidth'], linestyle=style_initial['linestyle']),
        Line2D([0],[0], color=style_neural['color'], linewidth=style_neural['linewidth'], linestyle=style_neural['linestyle']),
        Line2D([0],[0], color=style_heuristic['color'], linewidth=style_heuristic['linewidth'], linestyle=style_heuristic['linestyle']),
    ]
    legend_labels = ['$\pi_0$', '$\pi_c$', '$\pi_f$']
    ax.legend(
        legend_handles,
        legend_labels,
        loc='upper right',  # ← 固定在右下
    )

    plt.tight_layout()
    save_path_pdf = save_path.replace(".png", ".pdf")
    plt.savefig(save_path_pdf, dpi=300, bbox_inches='tight')
    plt.close(fig)

    # ============================================================
    #              中心格放大图（线宽按放大比例加粗）
    # ============================================================
    x_left, x_right = 2 / 3, 1
    y_bottom, y_top = 0, 1 / 3
    fig_center, ax_center = plt.subplots(figsize=(7,7))
    ax_center.set_aspect('equal', adjustable='box')
    ax_center.set_xlim(x_left, x_right)
    ax_center.set_ylim(y_bottom, y_top)

    # 放大比例因子（可根据图大小调整，这里取 7/7=1, 可根据需要修改）
    factor = 3  # 一般放大子图时线宽放大几倍

    style_initial_c = {**style_initial, 'linewidth': style_initial['linewidth']*factor}
    style_neural_c = {**style_neural, 'linewidth': style_neural['linewidth']*factor}
    style_heuristic_c = {**style_heuristic, 'linewidth': style_heuristic['linewidth']*factor}

    for u,v in E0: ax_center.plot([coords[u][0], coords[v][0]], [coords[u][1], coords[v][1]], **style_initial_c)
    for u,v in changed_1: ax_center.plot([coords[u][0], coords[v][0]], [coords[u][1], coords[v][1]], **style_neural_c)
    for u,v in changed_2: ax_center.plot([coords[u][0], coords[v][0]], [coords[u][1], coords[v][1]], **style_heuristic_c)

    ax_center.scatter(coords[:, 0], coords[:, 1], s=1*factor, color='black')

    # --- 子图 legend 把线宽也放大，使其与子图一致 ---
    legend_handles_center = [
        Line2D([0], [0],
               color=style_initial_c['color'],
               linewidth=style_initial_c['linewidth'],
               linestyle=style_initial_c['linestyle']),
        Line2D([0], [0],
               color=style_neural_c['color'],
               linewidth=style_neural_c['linewidth'],
               linestyle=style_neural_c['linestyle']),
        Line2D([0], [0],
               color=style_heuristic_c['color'],
               linewidth=style_heuristic_c['linewidth'],
               linestyle=style_heuristic_c['linestyle']),
    ]

    ax_center.legend(
        legend_handles_center,
        legend_labels,
        loc='upper right'
    )

    plt.tight_layout()

    center_save_path_pdf = save_path.replace(".png","_center.pdf")
    plt.savefig(center_save_path_pdf, dpi=300, bbox_inches='tight')
    plt.close(fig_center)

    print(f"[九宫格主图已保存] {save_path_pdf}")
    print(f"[九宫格中心图已保存（PDF高清）] {center_save_path_pdf}")









def run_with_separate_params(length_all, first_index_all, prob_size=1000):
    logger_params['log_file']['desc'] = f'test_matrix_{prob_size}'
    create_logger(**logger_params)

    env_params['data_path'] = b2 + datas[prob_size][0]
    env_params['budget'] = len(length_all)
    tester_params['model_load']['path'] = model_path[prob_size]
    tester_params['test_episodes'] = datas[prob_size][1]
    tester_params['test_batch_size'] = datas[prob_size][2]

    if prob_size==-1:
        env_params['test_in_tsplib'] = True
        env_params['tsplib_path'] = b2 + datas[prob_size][0]
        env_params['data_path'] = b2 + datas[prob_size][0]

    tester = Tester(env_params=env_params,
                    model_params=model_params,
                    tester_params=tester_params)

    copy_all_src(tester.result_folder)

    length_tensor = torch.tensor(length_all, dtype=torch.int64)
    index_tensor = torch.tensor(first_index_all, dtype=torch.int64)

    # 接收7个返回值
    score_optimal, score_student, gap, best_paths, batch_coords, initial_paths, initial_coords = tester.run(
        length_all=length_tensor, first_index_all=index_tensor
    )

    # 绘制 batch[0] 的图
    time_stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    draw_dir = os.path.join(tester.result_folder, "draw_pi", time_stamp)
    os.makedirs(draw_dir, exist_ok=True)

    # plot_paths(batch_coords[0], best_paths[0], 'Best Path Batch0', os.path.join(draw_dir, 'best_path_batch0.png'))
    # plot_paths(initial_coords[0], initial_paths[0], 'Initial Path Batch0', os.path.join(draw_dir, 'initial_path_batch0.png'))
    # 新增打印信息
    print(f"画图已保存到: {draw_dir}")
    return score_optimal, score_student, gap, best_paths, batch_coords, initial_paths, initial_coords, draw_dir

if __name__ == "__main__":
    import json
    import time

    # 加载 generate_params 函数
    generate_json_path = "json_prc/population_generation_10.json"
    with open(generate_json_path, "r") as f:
        content = json.load(f)
    code_str = content["code"]
    exec(code_str)  # 定义 generate_params

    # 加载 heuristic_optimize_from_json 所需路径
    heuristic_json_path = "json_2opt/population_generation_20.json"

    # 创建基础结果保存目录（不含时间戳）
    base_save_dir = "results_2opt"
    os.makedirs(base_save_dir, exist_ok=True)

    # 新增：生成时间戳目录
    time_stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    save_dir = os.path.join(base_save_dir, time_stamp)
    os.makedirs(save_dir, exist_ok=True)

    budget_list = [10]
    for prob_size in [10000]:
        for budget in budget_list:
            print(f"\n>>> 正在测试：prob_size={prob_size}, budget={budget}")
            length_all, first_index_all = generate_params(prob_size, budget)

            score_opt, score_stu, gap, best_paths, batch_coords, initial_paths, initial_coords, draw_dir = run_with_separate_params(
                length_all, first_index_all, prob_size=prob_size
            )
            print(f"Score(student) back to eoh: {score_stu:.4f}")
            # 先注释，没问题再取消注释添加最后的画图，只取第一条路径best_paths, batch_coords  0
            # 启发式优化计时开始
            start_time = time.time()

            opt_paths = []
            opt_lengths = []
            # 只优化第一条路径
            opt_path, opt_len = heuristic_optimize_from_json(best_paths[0], batch_coords[0], heuristic_json_path)
            opt_paths = [opt_path]
            opt_lengths = [opt_len]
            # # 绘制启发式优化后的路径图（第三个图）
            # plot_paths(batch_coords[0], opt_path, 'Optimized Path Batch0',
            #            os.path.join(draw_dir, 'optimized_path_batch0.png'))
            end_time = time.time()
            elapsed = round(end_time - start_time, 2)
            avg_opt_len = float(np.mean(opt_lengths))

            plot_integrated_improvement(
                batch_coords[0],
                initial_paths[0],
                best_paths[0],
                opt_path,
                os.path.join(draw_dir, 'integrated_improvement.png'),
                len_c=score_stu,  # πc
                len_f=opt_len  # πf
            )

            print(f"启发式优化后的平均路径长度: {avg_opt_len:.4f}")
            print(f"启发式优化总耗时: {elapsed:.2f} 秒")

            # 保存结果
            result = {
                "prob_size": prob_size,
                "budget": budget,
                "score_student": round(score_stu, 4),
                "avg_opt_length": round(avg_opt_len, 4),
                "heuristic_time_sec": elapsed
            }

            result_filename = f"result_probsize{prob_size}_budget{budget}.json"
            result_path = os.path.join(save_dir, result_filename)
            with open(result_path, "w") as fw:
                json.dump(result, fw, indent=2)
