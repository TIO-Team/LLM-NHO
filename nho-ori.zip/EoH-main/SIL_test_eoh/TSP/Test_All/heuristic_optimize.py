import json
import numpy as np
from typing import List, Dict, Tuple
import time  # 新增导入

def get_window_by_scale(n: int) -> int:
    if n <= 1000:
        return 300
    elif n <= 5000:
        return 400
    elif n <= 10000:
        return 500
    elif n <= 50000:
        return 800
    else:
        return 1000


def load_heuristic_from_json(json_path: str):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    code_str = data['code']
    local_vars = {}
    exec(code_str, globals(), local_vars)  # 动态执行代码，导出score函数
    if 'score' not in local_vars:
        raise ValueError("启发式json中未包含score函数")
    return local_vars['score']

def build_candidate_edges(coord: List[List[float]], score_func, tour: List[int], k: int = 20) -> Dict[int, List[int]]:
    coords_np = np.array(coord)
    n = len(tour)
    candidate_edges = {}

    window = get_window_by_scale(n)

    for i in range(n):
        current_node_idx = tour[i]
        current_node = coords_np[current_node_idx]

        # 环状窗口范围内的节点下标
        neighbor_indices = []
        for offset in range(-window, window + 1):
            if offset == 0:
                continue
            j = (i + offset) % n  # ✅ 环状取余
            neighbor_indices.append(tour[j])

        if not neighbor_indices:
            candidate_edges[current_node_idx] = []
            continue

        neighbor_coords = coords_np[neighbor_indices]
        scores = score_func(current_node, neighbor_coords)

        # 取 top-k
        top_k_idx = np.argsort(scores)[::-1][:k]
        top_k_nodes = [neighbor_indices[idx] for idx in top_k_idx]

        candidate_edges[current_node_idx] = top_k_nodes

    return candidate_edges


import time  # ✅ 增量式新增导入

def twoopt(candidate_edges: Dict[int, List[int]], tour: List[int], coord: List[List[float]], max_iter: int = 50) -> Tuple[List[int], float]:
    def path_length(path: List[int], coord: List[List[float]]) -> float:
        length = 0.0
        n = len(path)
        for i in range(n - 1):
            a, b = path[i], path[i + 1]
            dx = coord[a][0] - coord[b][0]
            dy = coord[a][1] - coord[b][1]
            length += np.sqrt(dx * dx + dy * dy)
        dx = coord[path[-1]][0] - coord[path[0]][0]
        dy = coord[path[-1]][1] - coord[path[0]][1]
        length += np.sqrt(dx * dx + dy * dy)
        return length

    path = tour[:]
    n = len(path)

    improved = True
    iter_count = 0
    start_time = time.time()  # ✅ 全局开始计时

    while improved and iter_count < max_iter:
        start_iter_time = time.time()  # ✅ 开始计时
        improved = False
        iter_count += 1

        for i in range(n - 1):
            node_i = path[i]
            node_i1 = path[i + 1]

            for neighbor in candidate_edges.get(node_i, []):
                j = path.index(neighbor)
                if j <= i + 1 or j == n - 1:
                    continue

                node_j = path[j]

                dist_before = np.linalg.norm(np.array(coord[node_i]) - np.array(coord[node_i1])) + \
                              np.linalg.norm(np.array(coord[node_j]) - np.array(coord[path[(j + 1) % n]]))
                dist_after = np.linalg.norm(np.array(coord[node_i]) - np.array(coord[node_j])) + \
                             np.linalg.norm(np.array(coord[node_i1]) - np.array(coord[path[(j + 1) % n]]))

                delta = dist_after - dist_before

                if delta < -1e-9:
                    path[i + 1:j + 1] = reversed(path[i + 1:j + 1])
                    improved = True
                    break
            if improved:
                break

        end_iter_time = time.time()  # ✅ 结束计时
        total_elapsed = end_iter_time - start_time
        if iter_count % 10==0:
            print(f"第 {iter_count} 轮耗时: {end_iter_time - start_iter_time:.4f} 秒")
            print(f"当前总耗时: {total_elapsed:.4f} 秒")
        # ✅ 累计耗时检查


        if total_elapsed > 1800:
            print(f"[警告] 累计耗时 {total_elapsed:.2f} 秒，超过 1800 秒，提前终止。")
            break
        iter_elapsed = end_iter_time - start_iter_time
        if iter_elapsed > 180:  # ✅
            print(f"[警告] 第 {iter_count} 轮耗时 {iter_elapsed:.2f} 秒，超过3分钟，提前终止。")
            break

    # if iter_count < max_iter:
    #     print(f"[警告] 提前终止：第 {iter_count} 轮后无任何 2-opt 改进。")
    # else:
    #     print(f"[提示] 已运行完整 {max_iter} 轮迭代。")

    final_length = path_length(path, coord)
    return path, final_length


def heuristic_optimize_from_json(tour: List[int], coord: List[List[float]], json_path: str, k: int = None, max_iter: int = None) -> Tuple[List[int], float]:
    n = len(tour)
    # 根据规模设置k

    # 固定最大迭代次数设为50
    if max_iter is None:
        max_iter = 50

    if k is None:
        if n <= 1000:
            k = 50
        elif n <= 5000:
            k = 50
        elif n <= 10000:
            k = 50
        elif n <= 50000:
            k = 20
        else:
            k = 20


    score_func = load_heuristic_from_json(json_path)
    start_build = time.time()
    candidate_edges = build_candidate_edges(coord, score_func, tour, k)
    end_build = time.time()

    start_opt = time.time()
    # print(f"candidate_edges 长度: {len(candidate_edges)}")  # ✅ 打印长度
    optimized_path, length = twoopt(candidate_edges, tour, coord, max_iter)
    end_opt = time.time()
    return optimized_path, length



