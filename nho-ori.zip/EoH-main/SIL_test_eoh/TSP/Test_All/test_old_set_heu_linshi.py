import os
import sys
# Setup path
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "..")
sys.path.insert(0, "../..")
import torch
import logging
import numpy as np
from utils.utils import create_logger, copy_all_src
from TSP.Test_All.TSPTester_save import TSPTester as Tester
from heuristic_optimize_cangshu import heuristic_optimize_from_json
import datetime  # 新增，用于时间戳

# 机器环境配置
DEBUG_MODE = False
USE_CUDA = not DEBUG_MODE
CUDA_DEVICE_NUM = 1

logger_params = {
    'log_file': {
        'desc': 'test_param_matrix',
        'filename': 'log.txt'
    }
}

env_params = {
    'pomo_size': 1,
    'k_nearest': 1,
    'beam_width': 16,
    'decode_method': 'greedy',
    'mode': 'test',
    'test_in_tsplib': False,
    'tsplib_path': None,
    'data_path': None,
    'load_way': 'allin',
    'sub_path': False,
    'budget': None,
    'PRC': True,
    'repair_max_sub_length': 1000,
    'random_insertion': True,
}

model_params = {
    'mode': 'test',
    'embedding_dim': 128,
    'sqrt_embedding_dim': 128 ** 0.5,
    'encoder_layer_num': 6,
    'qkv_dim': 16,
    'head_num': 8,
    'logit_clipping': 10,
    'ff_hidden_dim': 512,
    'eval_type': 'argmax',
    'use_k_nearest': True,
    'k_nearest_num': 1000,
}

tester_params = {
    'use_cuda': USE_CUDA,
    'cuda_device_num': CUDA_DEVICE_NUM,
    'model_load': {'path': None},
    'test_episodes': 128,
    'test_batch_size': 128,
}

b2 = os.path.abspath("..").replace('\\', '/')
datas = {
    1000: ['/data/test_set/MCTS_tsp1000_test_concorde.txt', 128, 128],
    5000: ['/data/test_set/test_tsp5000_lkh3_n16.txt', 16, 16],
    10000: ['/data/test_set/MCTS_tsp10000_test_concorde.txt', 16, 16],
    50000: ['/data/test_set/test_tsp50000_lkh3_n16.txt', 16, 8],
    100000: ['/data/test_set/test_tsp100000_lkh3_n16.txt', 16, 4],
    -1: ["/data/test_set/TSPlib_scale_ge_1K_n33_ascending.txt", 33, 1, 0]
}

model_path = {
    1000: './result/checkpoint-tsp1k.pt',
    5000: './result/checkpoint-tsp5k.pt',
    10000: './result/checkpoint-tsp10k.pt',
    50000: './result/checkpoint-tsp50k.pt',
    100000: './result/checkpoint-tsp100k.pt',
    -1: './result/checkpoint-tsp1k.pt',
}


def run_with_separate_params(length_all, first_index_all, prob_size=1000):
    logger_params['log_file']['desc'] = f'test_matrix_{prob_size}'
    create_logger(**logger_params)

    env_params['data_path'] = b2 + datas[prob_size][0]
    env_params['budget'] = len(length_all)
    tester_params['model_load']['path'] = model_path[prob_size]
    tester_params['test_episodes'] = datas[prob_size][1]
    tester_params['test_batch_size'] = datas[prob_size][2]

    tester = Tester(env_params=env_params,
                    model_params=model_params,
                    tester_params=tester_params)

    copy_all_src(tester.result_folder)

    length_tensor = torch.tensor(length_all, dtype=torch.int64)
    index_tensor = torch.tensor(first_index_all, dtype=torch.int64)

    # 修改这里，接收5个返回值
    score_optimal, score_student, gap, best_paths, batch_coords = tester.run(
        length_all=length_tensor, first_index_all=index_tensor
    )

    return score_optimal, score_student, gap, best_paths, batch_coords


if __name__ == "__main__":
    import json
    import time

    # === 是否使用本地存储数据 ===
    USE_LOCAL_DATA = True

    # 加载 generate_params 函数
    generate_json_path = "json_prc/population_generation_10.json"
    with open(generate_json_path, "r") as f:
        content = json.load(f)
    code_str = content["code"]
    exec(code_str)  # 定义 generate_params

    # 加载 heuristic_optimize_from_json 所需路径
    heuristic_json_path = "json_2opt/population_generation_20.json"

    # 创建基础结果保存目录（不含时间戳）
    base_save_dir = "results_2opt"
    os.makedirs(base_save_dir, exist_ok=True)

    # 新增：生成时间戳目录
    time_stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    save_dir = os.path.join(base_save_dir, time_stamp)
    os.makedirs(save_dir, exist_ok=True)

    budget_list = [1000]
    for prob_size in [10000]:
        for budget in budget_list:
            print(f"\n>>> 正在测试：prob_size={prob_size}, budget={budget}")
            try:
                if USE_LOCAL_DATA:
                    # === 本地加载 best_paths 和 batch_coords ===
                    best_paths = np.load(
                        f"2opt_test_data/best_paths_prob{prob_size}_budget{budget}.npy",
                        allow_pickle=True
                    ).tolist()
                    batch_coords = np.load(
                        f"2opt_test_data/batch_coords_prob{prob_size}_budget{budget}.npy",
                        allow_pickle=True
                    ).tolist()

                    score_stu = None  # 没有推理阶段的 student 分数

                else:
                    # 参数生成
                    length_all, first_index_all = generate_params(prob_size, budget)

                    # 推理与PRC修复
                    score_opt, score_stu, gap, best_paths, batch_coords = run_with_separate_params(
                        length_all, first_index_all, prob_size=prob_size
                    )
                    print(f"Score(student) back to eoh: {score_stu:.4f}")

                # === 这里开始：循环 k = 10,30,50,70,90 ===
                k_list = [10, 30, 50, 70, 90]
                all_results = {}

                # → 新：处理前 N 个实例
                N = 5
                paths = best_paths[:N]
                coords = batch_coords[:N]

                for cur_k in k_list:
                    print(f"\n>>> 运行 2opt 优化：k = {cur_k}")

                    opt_lens = []
                    times = []

                    for i in range(N):
                        start_time = time.time()

                        opt_path, opt_len = heuristic_optimize_from_json(
                            paths[i], coords[i], heuristic_json_path,
                            k=cur_k  # 外部传入 k
                            # window 和 max_iter 不传入，默认即可
                        )

                        end_time = time.time()
                        elapsed = end_time - start_time

                        opt_lens.append(opt_len)
                        times.append(elapsed)

                        print(f"实例{i}：长度={opt_len:.4f}, 耗时={elapsed:.2f}s")

                    # 取平均
                    avg_len = float(np.mean(opt_lens))
                    avg_time = float(np.mean(times))

                    print(f"→ 平均路径长度: {avg_len:.4f}")
                    print(f"→ 平均耗时: {avg_time:.2f} 秒")

                    all_results[cur_k] = {
                        "avg_opt_length": avg_len,
                        "avg_time_sec": avg_time
                    }

                # === 保存五次 k 的结果 ===
                result = {
                    "prob_size": prob_size,
                    "budget": budget,
                    "score_student": None if score_stu is None else round(score_stu, 4),
                    "results_by_k": all_results
                }

                result_filename = f"result_probsize{prob_size}_budget{budget}.json"
                result_path = os.path.join(save_dir, result_filename)

                with open(result_path, "w") as fw:
                    json.dump(result, fw, indent=2)

            except Exception as e:
                print(f"[Error] prob_size={prob_size}, budget={budget} failed: {e}")
