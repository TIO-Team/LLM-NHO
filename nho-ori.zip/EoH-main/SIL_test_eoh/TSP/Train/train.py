##########################################################################################
# 机器环境配置（是否使用 CUDA）

DEBUG_MODE = False  # 是否为调试模式，调试时不使用CUDA
USE_CUDA = not DEBUG_MODE  # 是否启用CUDA
CUDA_DEVICE_NUM = 6  # 指定使用的CUDA设备编号

##########################################################################################
# 路径配置

import os
import sys

# 设置当前工作目录为当前文件所在目录
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "..")    # 添加problem_def模块路径
sys.path.insert(0, "../..") # 添加utils模块路径

##########################################################################################
# 导入依赖模块

import logging
from utils.utils import create_logger, copy_all_src
from TSP.Train.TSPTrainer import TSPTester as Tester  # 导入Tester类

##########################################################################################
# 参数配置

# 获取当前路径（b）和上级路径（b2）
b = os.path.abspath(".").replace('\\', '/')
b2 = os.path.abspath("..").replace('\\', '/')

# 环境相关参数
env_params = {
    'mode': 'test',  # 模式：test or train
    'test_in_tsplib': False,  # 是否在TSPLIB上测试
    'tsplib_path': b + '/data/ALL_tsp/coordinate/TSPlib65.txt',  # TSPLIB数据路径
    'data_path': 'temp_repeaired_data.txt',  # 待修复数据路径
    'budget': 100,  # 解空间搜索预算
    'data_path_pt': [b + '/repaired_data', '/repeaired_data.pt', '/repeaired_data_solution.pt'],  # 修复后保存路径
    'PRC': True,  # 是否使用并行修复（True并行，False为单段）
    'max_subtour_length': 1000,  # 子回路最大长度
    'repair_max_sub_length': 1000,  # 修复过程中允许的子路径最大长度
    'RI_initial': True  # 是否采用RI（Random Insertion）初始化生成标签
}

# 模型参数配置
model_params = {
    'mode': 'test',
    'embedding_dim': 128,  # 节点嵌入维度
    'sqrt_embedding_dim': 128 ** (1 / 2),  # 根号嵌入维度，用于归一化
    'encoder_layer_num': 6,  # 编码器层数
    'qkv_dim': 16,  # QKV向量维度
    'head_num': 8,  # 注意力头数量
    'logit_clipping': 10,  # logits裁剪阈值
    'ff_hidden_dim': 512,  # 前馈隐藏层维度
    'k_nearest': False,  # 是否使用K近邻优化
    'k_nearest_num': 1000  # K近邻最大节点数
}

# 优化器参数
optimizer_params = {
    'optimizer': {
        'lr': 1e-4,  # 学习率
    },
    'scheduler': {
        'milestones': [1 * i for i in range(1, 300)],  # 学习率调整周期
        'gamma': 0.97  # 学习率衰减率
    }
}

# 测试器配置
tester_params = {
    'use_cuda': USE_CUDA,
    'cuda_device_num': CUDA_DEVICE_NUM,
    'model_load': {
        'path': None,  # 模型加载路径
        'epoch': None,  # 加载的模型epoch
    },
    'data_path': b2 + "/data/validation_set/validation_TSP1000_n128.txt",  # 测试数据路径
    'episodes': 4,     # 测试次数
    'batch_size': 4,   # 批次大小
}

# 训练器配置
trainer_params = {
    'episodes': [20000],  # 训练总样本数
    'problem_sizes': [1000],  # 问题规模（节点数）
    'repair_batch_size': [256],  # 修复过程的批大小
    'train_batch_size': [256],   # 训练过程的批大小
    'improve_iterations': 100,   # 改进迭代次数
    'epoch_itervel': 20,         # 每N轮训练保存一次
    'first_time_repair': True,   # 是否首次修复
    'repair_before_train': True, # 是否训练前先修复
    'epochs': 3000,              # 总训练轮数
    'logging': {
        'model_save_interval': 1,     # 模型保存间隔
        'img_save_interval': 3000,    # 图像保存间隔
        'log_image_params_1': {
            'json_foldername': 'log_image_style',
            'filename': 'style_tsp_100.json_2opt'
        },
        'log_image_params_2': {
            'json_foldername': 'log_image_style',
            'filename': 'style_loss_1.json_2opt'
        },
    },
}

# 日志配置
logger_params = {
    'log_file': {
        'desc': 'train_by_repair',  # 日志说明
        'filename': 'log.txt'       # 日志文件名
    }
}

##########################################################################################
# 主函数入口

def main(epoch, path, problem_sizes, eposides, train_batch_sizes, repair_batch_size,
         improve_iterations, budget, max_subtour_length, repair_max_sub_length,
         first_time_repair, repair_before_train, epoch_itervel, validation_sets, RI_initial):

    # 更新日志说明
    logger_params['log_file']['desc'] = f'train_by_SIL_TSP{problem_sizes[0]}'

    # 更新测试器模型加载路径和轮数
    tester_params['model_load'] = {
        'path': path,
        'epoch': epoch,
    }

    # 设置训练参数
    trainer_params['episodes'] = eposides
    trainer_params['problem_sizes'] = problem_sizes
    trainer_params['repair_batch_size'] = repair_batch_size
    trainer_params['train_batch_size'] = train_batch_sizes
    trainer_params['first_time_repair'] = first_time_repair
    trainer_params['repair_before_train'] = repair_before_train
    trainer_params['improve_iterations'] = improve_iterations
    trainer_params['epoch_itervel'] = epoch_itervel

    # 设置环境参数
    env_params['RI_initial'] = RI_initial
    env_params['budget'] = budget
    env_params['max_subtour_length'] = max_subtour_length
    env_params['repair_max_sub_length'] = repair_max_sub_length

    # 设置修复后数据保存路径（根据问题规模）
    env_params['data_path_pt'] = [b + f'/repaired_data{problem_sizes[0]}',
                                  f'/repaired_data{problem_sizes[0]}.pt',
                                  f'/repaired_data_solution{problem_sizes[0]}.pt']

    # 大规模问题时限制K近邻数量
    if problem_sizes[0] >= 10000:
        model_params['k_nearest_num'] = 10000

    # 设置测试数据路径、次数、batch大小
    tester_params['data_path'] = validation_sets[problem_sizes[0]][0]
    tester_params['episodes'] = validation_sets[problem_sizes[0]][1]
    tester_params['batch_size'] = validation_sets[problem_sizes[0]][2]

    # 创建日志并输出参数
    create_logger(**logger_params)
    _print_config()

    # 创建测试器
    tester = Tester(env_params=env_params,
                    model_params=model_params,
                    tester_params=tester_params,
                    trainer_params=trainer_params,
                    optimizer_params=optimizer_params)

    # 拷贝源码用于记录
    copy_all_src(tester.result_folder)

    # 启动训练或测试
    tester.run()
    return


# 打印配置信息到日志
def _print_config():
    logger = logging.getLogger('root')
    logger.info('DEBUG_MODE: {}'.format(DEBUG_MODE))
    logger.info('USE_CUDA: {}, CUDA_DEVICE_NUM: {}'.format(USE_CUDA, CUDA_DEVICE_NUM))
    [logger.info(g_key + "{}".format(globals()[g_key])) for g_key in globals().keys() if g_key.endswith('params')]

##########################################################################################

if __name__ == "__main__":

    '''
    提示：直接在 TSP1000 上从头训练，可能在若干轮后出现 loss=NaN。
    解决方案：
      1. 在loss变为NaN前保存模型，并在下一次迭代中继续使用；
      2. 在 optimizer.step() 前使用梯度裁剪，如：nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0, norm_type=2)
      3. 先在小规模TSP上预训练（如TSP100），再迁移至TSP1000。
    '''

    paras = {
        # 每个规模对应 [样本数，训练batch，修复batch，改进迭代次数]
        1000: [20000, 256, 256, 8],
        5000: [200, 32, 32, 8],
        10000: [200, 32, 32, 8],
        50000: [100, 32, 16, 8],
        100000: [100, 16, 8, 8],
    }

    # 验证集配置：路径、样本数、batch大小
    validation_sets = {
        1000: [b2 + "/data/validation_set/validation_TSP1000_n128.txt", 128, 32],
        5000: [b2 + "/data/validation_set/validation_TSP5000_n128.txt", 16, 16],
        10000: [b2 + "/data/validation_set/validation_TSP10000_n16.txt", 16, 16],
        50000: [b2 + "/data/validation_set/validation_TSP50000_n4.txt", 4, 4],
        100000: [b2 + "/data/validation_set/validation_TSP100000_n4.txt", 4, 4],
    }

    # 要训练的问题规模
    problem_sizes = [1000]

    # 通用训练参数设置
    epoch_itervel = 20
    max_subtour_length = 1000
    repair_max_sub_length = 1000
    budget = 100

    RI_initial = True  # 是否采用RI初始化伪标签
    path = None        # 若使用预训练模型，则指定路径
    epoch = None       # 若使用预训练模型，则指定加载epoch

    # 根据规模选择对应参数
    eposides = [paras[problem_sizes[0]][0]]
    train_batch_sizes = [paras[problem_sizes[0]][1]]
    repair_batch_size = [paras[problem_sizes[0]][2]]
    improve_iterations = paras[problem_sizes[0]][3]

    # 设置训练流程模式
    first_time_repair = True
    repair_before_train = True

    # 启动训练/测试
    main(epoch, path, problem_sizes, eposides, train_batch_sizes, repair_batch_size,
         improve_iterations, budget, max_subtour_length, repair_max_sub_length,
         first_time_repair, repair_before_train, epoch_itervel, validation_sets, RI_initial)
