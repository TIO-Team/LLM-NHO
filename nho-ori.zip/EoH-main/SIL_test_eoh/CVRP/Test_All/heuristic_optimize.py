import json
import numpy as np
from typing import List, Dict, Tuple

def load_heuristic_from_json(json_path: str):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    code_str = data['code']
    local_vars = {}
    exec(code_str, globals(), local_vars)  # 动态执行代码，导出score函数
    if 'score' not in local_vars:
        raise ValueError("启发式json中未包含score函数")
    return local_vars['score']

def build_candidate_edges(coord: List[List[float]], score_func, k: int = 10) -> Dict[int, List[int]]:
    coords_np = np.array(coord)
    n = len(coord)
    candidate_edges = {}

    for i in range(n):
        current_node = coords_np[i]
        scores = score_func(current_node, coords_np)
        scores[i] = -np.inf
        neighbors = np.argsort(scores)[::-1][:k]
        candidate_edges[i] = neighbors.tolist()

    return candidate_edges

def twoopt(candidate_edges: Dict[int, List[int]], tour: List[int], coord: List[List[float]], max_iter: int = 20) -> Tuple[List[int], float]:
    def path_length(path: List[int], coord: List[List[float]]) -> float:
        length = 0.0
        n = len(path)
        for i in range(n - 1):
            a, b = path[i], path[i + 1]
            dx = coord[a][0] - coord[b][0]
            dy = coord[a][1] - coord[b][1]
            length += np.sqrt(dx * dx + dy * dy)
        dx = coord[path[-1]][0] - coord[path[0]][0]
        dy = coord[path[-1]][1] - coord[path[0]][1]
        length += np.sqrt(dx * dx + dy * dy)
        return length

    path = tour[:]
    n = len(path)

    improved = True
    iter_count = 0

    while improved and iter_count < max_iter:
        improved = False
        iter_count += 1

        for i in range(n - 1):
            node_i = path[i]
            node_i1 = path[i + 1]

            for neighbor in candidate_edges.get(node_i, []):
                j = path.index(neighbor)
                if j <= i + 1 or j == n - 1:
                    continue

                node_j = path[j]

                dist_before = np.linalg.norm(np.array(coord[node_i]) - np.array(coord[node_i1])) + \
                              np.linalg.norm(np.array(coord[node_j]) - np.array(coord[path[(j + 1) % n]]))
                dist_after = np.linalg.norm(np.array(coord[node_i]) - np.array(coord[node_j])) + \
                             np.linalg.norm(np.array(coord[node_i1]) - np.array(coord[path[(j + 1) % n]]))

                delta = dist_after - dist_before

                if delta < -1e-9:
                    path[i + 1:j + 1] = reversed(path[i + 1:j + 1])
                    improved = True
                    break
            if improved:
                break

    final_length = path_length(path, coord)
    return path, final_length

def heuristic_optimize_from_json(tour: List[int], coord: List[List[float]], json_path: str, k: int = 10, max_iter: int = 20) -> Tuple[List[int], float]:
    score_func = load_heuristic_from_json(json_path)
    candidate_edges = build_candidate_edges(coord, score_func, k)
    optimized_path, length = twoopt(candidate_edges, tour, coord, max_iter)
    return optimized_path, length

if __name__ == "__main__":
    coords = [[0, 0], [1, 0], [1, 1], [0, 1]]
    initial_tour = [0, 1, 2, 3]  # 不重复起点
    json_path = "json_2opt/population_generation_1.json"

    opt_tour, opt_len = heuristic_optimize_from_json(initial_tour, coords, json_path, k=10, max_iter=10)
    print("优化后路径:", opt_tour)
    print("路径长度:", opt_len)
