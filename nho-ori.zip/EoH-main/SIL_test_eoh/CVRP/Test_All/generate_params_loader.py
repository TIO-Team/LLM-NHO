import json
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
generate_json_path = os.path.join(current_dir, "json_prc/population_generation_10.json")

with open(generate_json_path, "r") as f:
    content = json.load(f)
code_str = content["code"]
exec(code_str)  # 定义 generate_params
