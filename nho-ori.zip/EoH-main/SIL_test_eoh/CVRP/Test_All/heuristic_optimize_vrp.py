import json
import numpy as np
from typing import List, Tuple, Dict
import torch
import time

# -----------------------------
# 1️⃣ 加载启发式函数
# -----------------------------
def load_heuristic_from_json(json_path: str):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    code_str = data['code']
    local_vars = {}
    exec(code_str, globals(), local_vars)  # 导入 score 函数
    if 'score' not in local_vars:
        raise ValueError("启发式 JSON 中未包含 score 函数")
    return local_vars['score']

# -----------------------------
# 2️⃣ 构建子路径候选边集
# -----------------------------
def build_candidate_edges_subpath(subpath_nodes: List[int], coord: np.ndarray, score_func, k: int = 10) -> Dict[int, List[int]]:
    """
    只针对子路径节点构建候选边。
    返回 key/value 都是全局索引，与原路径一致。
    """
    candidate_edges = {}
    subpath_coords = coord[subpath_nodes]  # 子路径对应全局坐标
    n = len(subpath_nodes)

    # ✅ 打印子路径长度
    # print(f"Generating candidate edges for subpath of length: {n}")

    for local_idx, node in enumerate(subpath_nodes):
        current_coord = subpath_coords[local_idx]
        scores = score_func(current_coord, subpath_coords)
        scores[local_idx] = -np.inf  # 排除自身
        neighbors_local_idx = np.argsort(scores)[::-1][:k]
        neighbors_global = [subpath_nodes[i] for i in neighbors_local_idx]  # 转回全局索引
        candidate_edges[node] = neighbors_global

    return candidate_edges

# -----------------------------
# 3️⃣ 恢复完整路径（含仓库）
# -----------------------------
def full_path_from_labels(path_nodes: List[int], path_labels: List[int], depot_idx: int = 0) -> List[int]:
    full_path = []
    for node, label in zip(path_nodes, path_labels):
        if label == 1:
            full_path.append(depot_idx)  # 插入仓库
        full_path.append(node)
    full_path.append(depot_idx)  # 最后回仓库
    return full_path

# -----------------------------
# 4️⃣ 计算路径长度（含仓库）
# -----------------------------
def compute_total_length(best_paths: np.ndarray, coord: np.ndarray) -> float:
    total_length = 0.0
    path_nodes, path_labels = [], []
    for node, label in best_paths:
        if label == 1 and path_nodes:
            full_path = full_path_from_labels(path_nodes, path_labels)
            for i in range(len(full_path)-1):
                a, b = full_path[i], full_path[i+1]
                dx = coord[a][0] - coord[b][0]
                dy = coord[a][1] - coord[b][1]
                total_length += np.sqrt(dx*dx + dy*dy)
            path_nodes, path_labels = [], []
        path_nodes.append(node)
        path_labels.append(label)
    if path_nodes:
        full_path = full_path_from_labels(path_nodes, path_labels)
        for i in range(len(full_path)-1):
            a, b = full_path[i], full_path[i+1]
            dx = coord[a][0] - coord[b][0]
            dy = coord[a][1] - coord[b][1]
            total_length += np.sqrt(dx*dx + dy*dy)
    return total_length

# -----------------------------
# 5️⃣ two-opt 优化（单车子路径）
# -----------------------------
def twoopt(candidate_edges: Dict[int, List[int]], subpath: List[int], coord: np.ndarray, max_iter: int = 20) -> List[int]:
    path = subpath[:]
    n = len(path)
    improved = True
    iter_count = 0
    while improved and iter_count < max_iter:
        improved = False
        iter_count += 1
        for i in range(n - 1):
            node_i = path[i]
            node_i1 = path[i + 1]
            for neighbor in candidate_edges.get(node_i, []):
                try:
                    j = path.index(neighbor)
                except ValueError:
                    continue
                if j <= i + 1 or j == n - 1:
                    continue
                node_j = path[j]
                dist_before = np.linalg.norm(coord[node_i] - coord[node_i1]) + \
                              np.linalg.norm(coord[node_j] - coord[path[(j + 1) % n]])
                dist_after = np.linalg.norm(coord[node_i] - coord[node_j]) + \
                             np.linalg.norm(coord[node_i1] - coord[path[(j + 1) % n]])
                if dist_after < dist_before - 1e-9:
                    path[i + 1:j + 1] = reversed(path[i + 1:j + 1])
                    improved = True
                    break
            if improved:
                break

    # if iter_count < max_iter:
    #     print(f"[早停] 2-opt 在第 {iter_count} 轮后无改进，提前终止。")


    return path

# -----------------------------
# 6️⃣ CVRP 单实例子路径优化主函数
# -----------------------------
def heuristic_optimize_vrp(best_paths: np.ndarray, batch_coords: np.ndarray, json_path: str,
                           k: int = None, max_iter: int = None) -> Tuple[np.ndarray, float]:
    start_time = time.time()

    # 转 numpy
    if isinstance(best_paths, torch.Tensor):
        best_paths = best_paths.detach().cpu().numpy()
    if isinstance(batch_coords, torch.Tensor):
        batch_coords = batch_coords.detach().cpu().numpy()
    coord_np = batch_coords[:, :2]

    # 根据规模设置 k
    n_nodes = coord_np.shape[0]
    if k is None:
        if n_nodes <= 1000:
            k = 50
        elif n_nodes <= 5000:
            k = 50
        elif n_nodes <= 10000:
            k = 50
        elif n_nodes <= 50000:
            k = 20
        else:
            k = 20
    # 固定最大迭代次数
    if max_iter is None:
        max_iter = 50

    # 加载启发式 score
    score_func = load_heuristic_from_json(json_path)

    optimized_path_list = []
    total_length = 0.0
    path_nodes, path_labels = [], []

    for node, label in best_paths:
        if label == 1 and path_nodes:
            # 构建子路径候选边
            candidate_edges_sub = build_candidate_edges_subpath(path_nodes, coord_np, score_func, k)
            # two-opt 优化子路径
            path_nodes = twoopt(candidate_edges_sub, path_nodes, coord_np, max_iter)
            # 计算子路径长度
            total_length += compute_total_length(np.array([[n, l] for n, l in zip(path_nodes, path_labels)]), coord_np)
            # 保存优化结果
            for n, l in zip(path_nodes, path_labels):
                optimized_path_list.append([n, l])
            path_nodes, path_labels = [], []
        path_nodes.append(node)
        path_labels.append(label)

    # 处理最后一段子路径
    if path_nodes:
        candidate_edges_sub = build_candidate_edges_subpath(path_nodes, coord_np, score_func, k)
        path_nodes = twoopt(candidate_edges_sub, path_nodes, coord_np, max_iter)
        total_length += compute_total_length(np.array([[n, l] for n, l in zip(path_nodes, path_labels)]), coord_np)
        for n, l in zip(path_nodes, path_labels):
            optimized_path_list.append([n, l])

    end_time = time.time()
    # print(f"heuristic_optimize_vrp 耗时: {end_time - start_time:.2f}s")

    return np.array(optimized_path_list), total_length


