##########################################################################################
# Machine Environment Config

DEBUG_MODE = False
USE_CUDA = not DEBUG_MODE
CUDA_DEVICE_NUM = 7

##########################################################################################
# Path Config

import os
import sys

os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "..")  # for problem_def
sys.path.insert(0, "../..")  # for utils
import logging
import torch
import json
from utils.utils import create_logger, copy_all_src
from CVRP.Test_All.VRPTester_new import VRPTester as Tester
from heuristic_optimize_vrp import heuristic_optimize_vrp

##########################################################################################
# Global params

b2 = os.path.abspath("..").replace('\\', '/')

env_params = {
    'pomo_size': 1,
    'k_nearest': 1,
    'beam_width': 16,
    'decode_method': 'greedy',
    'mode': 'test',
    'test_in_vrplib': False,
    'vrplib_path': None,
    'data_path': None,
    'load_way': 'allin',
    'sub_path': False,
    'budget': None,
    'PRC': True,
    'repair_max_sub_length': 1000,
    'random_insertion': True,
}

model_params = {
    'mode': 'test',
    'embedding_dim': 128,
    'sqrt_embedding_dim': 128**0.5,
    'decoder_layer_num': 6,
    'qkv_dim': 16,
    'head_num': 8,
    'logit_clipping': 10,
    'ff_hidden_dim': 512,
    'eval_type': 'argmax',
    'use_k_nearest': True,
    'k_nearest_num': 1000,
}

tester_params = {
    'use_cuda': USE_CUDA,
    'cuda_device_num': CUDA_DEVICE_NUM,
    'model_load': {'path': None},
    'test_episodes': 16,
    'test_batch_size': 4,
    'augmentation_enable': False,
    'aug_factor': 1,
    'aug_batch_size': 100,
}

if tester_params['augmentation_enable']:
    tester_params['test_batch_size'] = tester_params['aug_batch_size']

logger_params = {
    'log_file': {
        'desc': 'test_param_matrix_cvrp',
        'filename': 'log.txt'
    }
}

datas = {
    1000: ['/data/test_set/test_cvrp1000_hgs_n128_C250.txt', 128, 128],
    5000: ['/data/test_set/test_cvrp5000_hgs_n16_C500.txt', 16, 16],
    10000: ['/data/test_set/test_cvrp10000_hgs_n16_C1000.txt', 16, 16],
    50000: ['/data/test_set/test_cvrp50000_hgs_n16_C2000.txt', 16, 8],
    100000: ['/data/test_set/test_cvrp100000_hgs_n16_C2000.txt', 16, 4],
    -1: ['/data/test_set/CVRPlib_scale_larger_than1000_Li_X_XXL_n14.txt', 14, 1]
}

model_path = {
    1000: './result/checkpoint-cvrp1k.pt',
    5000: './result/checkpoint-cvrp5k.pt',
    10000: './result/checkpoint-cvrp10k.pt',
    50000: './result/checkpoint-cvrp50k.pt',
    100000: './result/checkpoint-cvrp100k.pt',
    -1: './result/checkpoint-cvrp1k.pt',
}

##########################################################################################
# Utility function

def save_numpy(path, tensor_or_array):
    """安全保存 numpy/tensor 到文件"""
    if isinstance(tensor_or_array, torch.Tensor):
        tensor_or_array = tensor_or_array.detach().cpu().numpy()
    import numpy as np
    np.save(path, tensor_or_array)

##########################################################################################
# Functions

def _print_config():
    logger = logging.getLogger('root')
    logger.info(f'DEBUG_MODE: {DEBUG_MODE}')
    logger.info(f'USE_CUDA: {USE_CUDA}, CUDA_DEVICE_NUM: {CUDA_DEVICE_NUM}')
    for key in globals().keys():
        if key.endswith('params'):
            logger.info(f'{key}: {globals()[key]}')

def run_with_separate_params(length_all, first_index_all, prob_size=1000,
                             PRC=True,
                             repair_max_sub_length=1000,
                             random_insertion=True):
    logger_params['log_file']['desc'] = f'test_matrix_cvrp_{prob_size}'
    create_logger(**logger_params)

    env_params['data_path'] = b2 + datas[prob_size][0]
    env_params['budget'] = len(length_all)
    env_params['PRC'] = PRC
    env_params['repair_max_sub_length'] = repair_max_sub_length
    env_params['random_insertion'] = random_insertion

    tester_params['model_load']['path'] = model_path[prob_size]
    tester_params['test_episodes'] = datas[prob_size][1]
    tester_params['test_batch_size'] = datas[prob_size][2]

    tester = Tester(env_params=env_params,
                    model_params=model_params,
                    tester_params=tester_params)

    _print_config()
    copy_all_src(tester.result_folder)

    length_tensor = torch.tensor(length_all, dtype=torch.int64)
    index_tensor = torch.tensor(first_index_all, dtype=torch.int64)

    score_optimal, score_student, gap, best_paths, batch_coords = tester.run(
        length_all=length_tensor, first_index_all=index_tensor)
    # 打印 best_paths 的形状
    print("best_paths shape:", best_paths.shape)
    print("Number of paths:", best_paths.shape[0])

    return score_optimal, score_student, gap, best_paths, batch_coords

##########################################################################################
# Entry

import json
import time
import os
import numpy as np

if __name__ == "__main__":
    # 加载 generate_params 函数
    generate_json_path = "json_prc/population_generation_10.json"
    with open(generate_json_path, "r") as f:
        content = json.load(f)
    exec(content["code"])  # 定义 generate_params

    # VRP 启发式优化json路径
    heuristic_json_path = "json_2opt/population_generation_20.json"

    # 创建基础结果保存目录
    base_save_dir = "results_2opt"
    os.makedirs(base_save_dir, exist_ok=True)

    # 生成时间戳子目录
    import datetime
    time_stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    save_dir = os.path.join(base_save_dir, time_stamp)
    os.makedirs(save_dir, exist_ok=True)

    budget_list = [1000]
    for prob_size in [5000, 10000, 50000]:
        for budget in budget_list:
            print(f"\n>>> 正在测试：prob_size={prob_size}, budget={budget}")

            # 参数生成
            length_all, first_index_all = generate_params(prob_size, budget)

            # 调用 VRP 测试推理接口，获得路径与坐标
            score_opt, score_stu, gap, best_paths, batch_coords = run_with_separate_params(
                length_all, first_index_all, prob_size=prob_size
            )

            # === 使用 save_numpy 保存 ===
            save_test_data_dir = "2opt_test_data_vrp"
            os.makedirs(save_test_data_dir, exist_ok=True)

            save_numpy(os.path.join(save_test_data_dir, f"best_paths_prob{prob_size}_budget{budget}.npy"), best_paths)
            save_numpy(os.path.join(save_test_data_dir, f"batch_coords_prob{prob_size}_budget{budget}.npy"), batch_coords)

            print(f"[保存] best_paths 和 batch_coords 已写入 {save_test_data_dir}/")
