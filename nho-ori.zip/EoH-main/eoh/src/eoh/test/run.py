### Test Only ###
# Set system path
import sys
import os
ABS_PATH = os.path.dirname(os.path.abspath(__file__))
ROOT_PATH = os.path.join(ABS_PATH, "..", "..")
sys.path.append(ROOT_PATH)  # This is for finding all the modules
sys.path.append(ABS_PATH)
print(ABS_PATH)
from eoh import eoh
from eoh.utils.getParas import Paras
# from evol.utils.createReport import ReportCreator


# Parameter initilization #
paras = Paras() 

# Set parameters #
paras.set_paras(method = "eoh",    
                ec_operators  = ['e1','e2','m1','m2','m3'], # operators in EoH
                problem = "large_tsp", # ['tsp_construct','bp_online','tsp_gls','fssp_gls',large_tsp， improve_tsp， encoder_design]
                llm_api_endpoint="api.deepseek.com",  # set endpoint
                # llm_api_endpoint="api.deepseek.com",  # set endpoint
                # llm_api_key="sk-bd553f4a01d440da89d48d4aba8a073f",  # set your key
                llm_api_key="xxxxxx",  # set your key
                llm_model="xxx",  # set llm
                # llm_model="deepseek-chat",  # set llm
                ec_pop_size = 4,
                ec_n_pop = 20,    # 代表代数或者轮数，进行一次e1到m3为一轮
                exp_n_proc = 1,
                exp_debug_mode = False)

# llm_api_endpoint = "api.chatanywhere.tech",  # set endpoint
# llm_api_key = "sk-FCip3RKWiNYXPRCFyx7fdBXlfpnl4CpD06vMf0xeCCmepAou",  # set your key
# llm_model = "gpt-3.5-turbo",  # set llm

# llm_api_endpoint = "api.deepseek.com",  # set endpoint
# llm_api_key = "sk-bd553f4a01d440da89d48d4aba8a073f",  # set your key
# llm_model = "deepseek-chat",  # set llm

# EoH initilization
evolution = eoh.EVOL(paras)

# run EoH
evolution.run()

# Generate EoH Report
# RC = ReportCreator(paras)
# RC.generate_doc_report()




