class GetPrompts():
    def __init__(self):
        self.prompt_task = (
            "Design a novel score function to evaluate all nodes as candidates to connect from a given node, "
            "for selecting promising edges in TSP 2-opt repair."
            "Nodes with higher scores will be more likely to be selected for 2-opt search."
        )

        self.prompt_func_name = "score"
        self.prompt_func_inputs = ['current_node', 'all_nodes']
        self.prompt_func_outputs = ['scores']

        self.prompt_inout_inf = (
            "'current_node': 1D Numpy array of shape (2,);\n"
            "'all_nodes': 2D Numpy array of shape (N, 2);\n"
            "'scores': 1D array of length N indicating connection preference (higher is better)."
        )

        self.prompt_other_inf = (
            "Avoid time-consuming calculations. "
            "Ensure consistency. Include 'import numpy as np' and '@jit(nopython=True)' before the function."
        )

    def get_task(self): return self.prompt_task
    def get_func_name(self): return self.prompt_func_name
    def get_func_inputs(self): return self.prompt_func_inputs
    def get_func_outputs(self): return self.prompt_func_outputs
    def get_inout_inf(self): return self.prompt_inout_inf
    def get_other_inf(self): return self.prompt_other_inf
