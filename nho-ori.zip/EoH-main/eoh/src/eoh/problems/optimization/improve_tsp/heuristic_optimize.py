import numpy as np
from typing import List, Dict, Tuple


def twoopt(candidate_edges: Dict[int, List[int]], tour: List[int], coord: List[List[float]], max_iter: int = 20) -> \
Tuple[List[int], float]:
    """
    基于候选边集的2-opt优化

    candidate_edges: 每个节点对应的候选邻居列表（优先考虑交换的边）
    tour: 当前路径，闭合路径形式（首尾相同）
    coord: 节点坐标列表，格式 [[x0,y0], [x1,y1], ...]
    max_iter: 最大迭代次数

    返回优化后的路径和对应路径长度
    """

    def path_length(path: List[int], coord: List[List[float]]) -> float:
        length = 0.0
        n = len(path)
        for i in range(n - 1):
            a, b = path[i], path[i + 1]
            dx = coord[a][0] - coord[b][0]
            dy = coord[a][1] - coord[b][1]
            length += np.sqrt(dx * dx + dy * dy)
        return length

    path = tour[:]  # 拷贝，避免原始路径被修改
    n = len(path)

    improved = True
    iter_count = 0

    while improved and iter_count < max_iter:
        improved = False
        iter_count += 1

        for i in range(n - 1):
            node_i = path[i]
            node_i1 = path[i + 1]

            for neighbor in candidate_edges.get(node_i, []):
                if neighbor not in path:
                    continue
                j = path.index(neighbor)
                if j <= i + 1 or j == n - 1:
                    # j 必须在 i+2 之后，且不处理最后闭合边的情况
                    continue

                node_j = path[j]
                node_j1 = path[(j + 1) % n]

                # 计算交换前后边的距离差
                dist_before = np.linalg.norm(np.array(coord[node_i]) - np.array(coord[node_i1])) + \
                              np.linalg.norm(np.array(coord[node_j]) - np.array(coord[node_j1]))
                dist_after = np.linalg.norm(np.array(coord[node_i]) - np.array(coord[node_j])) + \
                             np.linalg.norm(np.array(coord[node_i1]) - np.array(coord[node_j1]))

                delta = dist_after - dist_before

                if delta < -1e-9:
                    # 反转 i+1 到 j 的子路径
                    path[i + 1:j + 1] = reversed(path[i + 1:j + 1])
                    improved = True
                    break
            if improved:
                break

    final_length = path_length(path, coord)
    return path, final_length
