import requests

url = "https://api.deepseek.com/v1/chat/completions"
headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer sk-bd553f4a01d440da89d48d4aba8a073f"  # 替换为你的 key
}
data = {
    "model": "deepseek-chat",
    "messages": [{"role": "user", "content": "Hello, how are you?"}],
    "temperature": 0
}

response = requests.post(url, headers=headers, json=data)
print("Status Code:", response.status_code)
print("Response:", response.json())
