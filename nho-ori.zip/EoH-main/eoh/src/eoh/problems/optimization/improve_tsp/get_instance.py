import os
import numpy as np

class GetData():
    def __init__(self):
        current_dir = os.path.dirname(os.path.abspath(__file__))  # 当前文件的目录
        self.data_path = os.path.join(current_dir, "heu_eoh_data", "data_for_eoh.npz")

    def get_instances(self, num_instances=4):  # 新增参数，默认读取前4个
        data = np.load(self.data_path, allow_pickle=True)
        print("成功读取数据")

        tours = data["best_paths"]
        coords = data["coordinates"]

        # 只保留前 num_instances 个实例
        total = min(len(tours), num_instances)

        instances = {}
        for i in range(total):
            tour = tours[i].tolist()
            # 补全闭环：如果首尾节点不同，则加上首节点
            if tour[0] != tour[-1]:
                tour.append(tour[0])

            instances[i] = {
                'tour': tour,
                'coord': coords[i].tolist()
            }

        return instances
