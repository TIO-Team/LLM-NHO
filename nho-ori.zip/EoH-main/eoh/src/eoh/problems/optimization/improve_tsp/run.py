import numpy as np
import importlib
from .get_instance import GetData
from .prompts import GetPrompts
from .heuristic_optimize import twoopt
import types
import warnings
import sys
import time


class IMPROVE_TSP():
    def __init__(self):
        getdata = GetData()
        self.instances = getdata.get_instances()
        self.prompts = GetPrompts()

    def build_candidate_edges(self, score_func, coord, tour, top_k=5, timeout_seconds=60):
        candidate_edges = {}
        all_nodes = np.array(coord)
        start_time = time.time()

        for current_node in range(len(coord)):
            if time.time() - start_time > timeout_seconds:
                print(f"[超时] 构造候选边超过 {timeout_seconds} 秒，提前终止。")
                return None

            current_coord = np.array(coord[current_node])
            scores = score_func(current_coord, all_nodes)
            sorted_indices = np.argsort(scores)[::-1]
            candidates = [i for i in sorted_indices if i != current_node][:top_k]
            candidate_edges[current_node] = candidates

        return candidate_edges

    def evaluateGreedy(self, alg) -> float:
        print("强限制时间，避免构造侯选边集时长爆炸")
        """
        执行 2-opt 路径修复，并评估平均提升效果。
        如果总耗时超过 5 分钟，则中断；若个别构造步骤耗时超过 60 秒则跳过。
        """
        gap_list = []
        original_lengths = []
        improved_lengths = []

        start_time = time.time()
        timeout_seconds = 300  # 全局超时5min
        build_timeout = 120     # 每个构造侯选边步骤的超时限制2min

        for i, instance in self.instances.items():
            elapsed = time.time() - start_time
            if elapsed > timeout_seconds:
                print(f"[超时] 超过最大允许时间 {timeout_seconds} 秒，终止评估。")
                return None

            tour = instance['tour']
            coord = instance['coord']

            if tour[0] != tour[-1]:
                tour = tour + [tour[0]]

            t0 = time.time()
            candidate_edges = self.build_candidate_edges(
                score_func=alg.score,
                coord=coord,
                tour=tour,
                timeout_seconds=build_timeout
            )
            t1 = time.time()

            if candidate_edges is None:
                print(f"[跳过] 实例 {i} 构造候选边超时，跳过此轮。")
                continue

            print(f"[{i}] 得到一个实例候选边集，用时 {t1 - t0:.2f} 秒")

            original_length = self.calc_tour_length(tour, coord)
            t2 = time.time()
            improved_tour, improved_length = twoopt(candidate_edges, tour, coord)
            t3 = time.time()
            print(f"[{i}] 算完一个实例一次 2-opt，用时 {t3 - t2:.2f} 秒")
            print(f"[{i}] 路径提升值: {original_length - improved_length:.4f}")

            errors = self.sanity_check_tsp(improved_tour, coord)
            if errors:
                print(f"[警告] 实例 {i} 的修复路径非法:")
                for err in errors:
                    print("  -", err)

            if improved_length > original_length + 1e-6:
                print(f"[异常] 实例 {i} 修复后路径变长：原 {original_length:.4f} → 新 {improved_length:.4f}")

            gap = (original_length - improved_length) / original_length
            gap_list.append(gap)
            original_lengths.append(original_length)
            improved_lengths.append(improved_length)

        if not improved_lengths:
            print("[失败] 所有实例均失败，无法评估。")
            return None

        print(f"[TSP修复评估] 原始平均路径长度:   {np.mean(original_lengths):.4f}")
        print(f"[TSP修复评估] 修复后平均路径长度: {np.mean(improved_lengths):.4f}")
        return np.mean(improved_lengths)

    def calc_tour_length(self, tour, coord):
        if tour[0] != tour[-1]:
            tour = tour + [tour[0]]
        total = 0.0
        for i in range(len(tour) - 1):
            a, b = tour[i], tour[i + 1]
            total += np.linalg.norm(np.array(coord[a]) - np.array(coord[b]))
        return total

    def sanity_check_tsp(self, tour, coord):
        errors = []
        n = len(coord)
        if tour[0] != tour[-1]:
            errors.append("Tour is not closed (first node != last node).")
        if len(set(tour[:-1])) != len(tour) - 1:
            errors.append("Tour contains duplicate nodes (excluding last repeat).")
        if set(tour[:-1]) != set(range(n)):
            missing = set(range(n)) - set(tour[:-1])
            extra = set(tour[:-1]) - set(range(n))
            if missing:
                errors.append(f"Tour missing cities: {missing}")
            if extra:
                errors.append(f"Tour contains invalid cities: {extra}")
        return errors

    def evaluate(self, code_string):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                heuristic_module = types.ModuleType("heuristic_module")
                exec(code_string, heuristic_module.__dict__)
                sys.modules[heuristic_module.__name__] = heuristic_module
                return self.evaluateGreedy(heuristic_module)
        except Exception as e:
            print("[错误] 执行评分函数时报错：", str(e))
            return None
