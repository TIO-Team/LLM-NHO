# def heuristic_optimize(paths, distance_matrices):
#     """
#     目前不做修改，直接返回输入。
#     """
#     return paths, [sum(distance_matrices[i][p[j], p[j+1]] for j in range(len(p)-1)) + distance_matrices[i][p[-1], p[0]]
#                    for i, p in enumerate(paths)]


import numpy as np

def heuristic_optimize(paths, distance_matrices, k_nearest_neighbors=20, max_iter=10):
    """
    基于k近邻候选边的快速2-opt（简化版，不再支持传入knn列表）

    paths: list of lists，路径序列
    distance_matrices: list of np.ndarray，距离矩阵
    k_nearest_neighbors: int，每个节点考虑的近邻数（默认20）
    max_iter: 最大迭代轮数

    返回优化后的路径和路径长度列表
    """

    def path_length(path, dist_mat):
        length = 0.0
        n = len(path)
        for i in range(n - 1):
            length += dist_mat[path[i], path[i + 1]]
        length += dist_mat[path[-1], path[0]]
        return length

    optimized_paths = []
    optimized_lengths = []

    for idx, path in enumerate(paths):
        dist_mat = distance_matrices[idx]
        path = path[:]  # 深复制以避免修改原始路径
        n = len(path)

        # 计算 k近邻矩阵（每个节点的 k 个最近邻，不含自身）
        knn = np.argsort(dist_mat, axis=1)[:, 1:k_nearest_neighbors + 1]

        original_length = path_length(path, dist_mat)
        print(f"[{idx + 1}/{len(paths)}] Original Length: {original_length:.4f}")

        improved = True
        iter_count = 0

        while improved and iter_count < max_iter:
            improved = False
            iter_count += 1

            for i in range(n - 1):
                node_i = path[i]
                for neighbor in knn[node_i]:
                    if neighbor not in path:
                        continue
                    j = path.index(neighbor)
                    if j <= i + 1:
                        continue

                    a, b = path[i], path[i + 1]
                    c, d = path[j], path[(j + 1) % n]

                    delta = dist_mat[a, c] + dist_mat[b, d] - dist_mat[a, b] - dist_mat[c, d]

                    if delta < -1e-9:
                        path[i + 1:j + 1] = reversed(path[i + 1:j + 1])
                        improved = True
                        print(f"  Iter {iter_count}: 2-opt improvement (Δ={delta:.6f})")
                        break
                if improved:
                    break

        final_length = path_length(path, dist_mat)
        print(f"  Done in {iter_count} iter(s). Final Length: {final_length:.4f} | Gain: {original_length - final_length:.4f}\n")

        optimized_paths.append(path)
        optimized_lengths.append(final_length)

    return optimized_paths, optimized_lengths


