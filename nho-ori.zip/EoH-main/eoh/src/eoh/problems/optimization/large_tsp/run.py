import sys
import types
import warnings
from .prompts import GetPrompts
from .SIL_main.TSP.Test_All.test_with_param import run_with_separate_params


class LARGETSP():
    def __init__(self):
        # 目前暂时在此修改参数，仅有5000是新的训练数据
        self.prob_size = 5000  # 可设为 1000 / 5000 / ...
        self.budget = 10  # 每次扰动数量（等于 length_all 的长度）
        self.prompts = GetPrompts()

    def evaluate(self, code_string):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                mod = types.ModuleType("heuristic_module")
                exec(code_string, mod.__dict__)

                # ==== 构造生成参数函数所需的输入 ====
                problem_size = self.prob_size
                budget = self.budget

                # 后续再加这两参数
                # tour_node_sequence = list(range(problem_size))  # 假设顺序巡回
                # original_tour_length = problem_size  # 暂定为 dummy 值


                length_all, first_index_all = mod.generate_params(
                    problem_size,
                    budget
                )

                # 检查 length_all
                for l in length_all:
                    if not (4 <= l <= 5000):
                        print(f"Illegal length: {l}")
                        return None

                problem_size_test = 100000
                # 测试未来泛化，若当前不超5000，但在例如10w规模时得到的长度参数超1w，也认为是非法启发式
                length_test, first_index_test = mod.generate_params(
                    problem_size_test,
                    budget
                )

                for l in length_test:
                    if not (4 <= l <= 10000):
                        print(f"Illegal length in test problem size 100000: {l}")
                        return None

                # ==== 调用 SIL 模型进行路径修复 ====
                score_opt, score_stu, gap = run_with_separate_params(
                    length_all, first_index_all, prob_size=problem_size
                )

                return score_stu  # 越小越好

        except Exception as e:
            print("Evaluation error:", str(e))
            return None

