import os
import sys
# Setup path
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "..")
sys.path.insert(0, "../..")
import torch
import logging
import numpy as np
from utils.utils import create_logger, copy_all_src
from TSP.Test_All.TSPTester_save import TSPTester as Tester
from heuristic_optimize import heuristic_optimize

# 机器环境配置
DEBUG_MODE = False
USE_CUDA = not DEBUG_MODE
CUDA_DEVICE_NUM = 6


logger_params = {
    'log_file': {
        'desc': 'test_param_matrix',
        'filename': 'log.txt'
    }
}

env_params = {
    'pomo_size': 1,
    'k_nearest': 1,
    'beam_width': 16,
    'decode_method': 'greedy',
    'mode': 'test',
    'test_in_tsplib': False,
    'tsplib_path': None,
    'data_path': None,
    'load_way': 'allin',
    'sub_path': False,
    'budget': None,
    'PRC': True,
    'repair_max_sub_length': 1000,
    'random_insertion': True,
}

model_params = {
    'mode': 'test',
    'embedding_dim': 128,
    'sqrt_embedding_dim': 128 ** 0.5,
    'encoder_layer_num': 6,
    'qkv_dim': 16,
    'head_num': 8,
    'logit_clipping': 10,
    'ff_hidden_dim': 512,
    'eval_type': 'argmax',
    'use_k_nearest': True,
    'k_nearest_num': 1000,
}

tester_params = {
    'use_cuda': USE_CUDA,
    'cuda_device_num': CUDA_DEVICE_NUM,
    'model_load': {'path': None},
    'test_episodes': 128,
    'test_batch_size': 128,
}

b2 = os.path.abspath("..").replace('\\', '/')
datas = {
    1000: ['/data/test_set/MCTS_tsp1000_test_concorde.txt', 128, 128],
    5000: ['/data/train_eoh_set/data/validation_TSP5000_16.txt', 16, 16],     # 自己的随机数据
    10000: ['/data/test_set/MCTS_tsp10000_test_concorde.txt', 16, 16],
    50000: ['/data/test_set/test_tsp50000_lkh3_n16.txt', 16, 8],
    100000: ['/data/test_set/test_tsp100000_lkh3_n16.txt', 16, 4],
    -1: ["/data/test_set/TSPlib_scale_ge_1K_n33_ascending.txt", 33, 1, 0]
}

model_path = {
    1000: './result/checkpoint-tsp1k.pt',
    5000: './result/checkpoint-tsp5k.pt',
    10000: './result/checkpoint-tsp10k.pt',
    50000: './result/checkpoint-tsp50k.pt',
    100000: './result/checkpoint-tsp100k.pt',
    -1: './result/checkpoint-tsp1k.pt',
}


def run_with_separate_params(length_all, first_index_all, prob_size=1000):
    logger_params['log_file']['desc'] = f'test_matrix_{prob_size}'
    create_logger(**logger_params)

    env_params['data_path'] = b2 + datas[prob_size][0]
    env_params['budget'] = len(length_all)
    tester_params['model_load']['path'] = model_path[prob_size]
    tester_params['test_episodes'] = datas[prob_size][1]
    tester_params['test_batch_size'] = datas[prob_size][2]

    tester = Tester(env_params=env_params,
                    model_params=model_params,
                    tester_params=tester_params)

    copy_all_src(tester.result_folder)

    length_tensor = torch.tensor(length_all, dtype=torch.int64)
    index_tensor = torch.tensor(first_index_all, dtype=torch.int64)

    # 接收5个返回值，注意第五个是坐标数组，不是距离矩阵
    score_optimal, score_student, gap, best_paths, coordinates = tester.run(length_all=length_tensor, first_index_all=index_tensor)

    return score_optimal, score_student, gap, best_paths, coordinates


if __name__ == "__main__":
    import json

    prob_size = 5000
    budget = 10

    json_path = "../../../../../../../../../eoh/src/test/results_2025-07-30_12-37-01/results/pops_best/population_generation_20.json_2opt"
    # json_path = "../../../../../../../../../eoh/src/test/results_2025-07-19_10-23-20/results/pops_best/population_generation_1.json_2opt"
    # /home/dongxinbu1/project/eoh/eoh/src/test/results_2025-07-30_12-37-01/results/pops_best/population_generation_20.json_2opt
    with open(json_path, "r") as f:
        content = json.load(f)

    code_str = content["code"]

    exec(code_str)  # 定义 generate_params 函数

    length_all, first_index_all = generate_params(prob_size, budget)

    score_opt, score_stu, gap, best_paths, coordinates = run_with_separate_params(length_all, first_index_all, prob_size=prob_size)
    print(f"Score(student) back to eoh: {score_stu:.4f}")

    # === 保存所有实例的 best_paths 和 coordinates 到 heu_eoh_data/data_for_eoh.npz ===
    current_dir = os.path.dirname(os.path.abspath(__file__))  # 获取当前脚本目录
    save_dir = os.path.join(current_dir, "heu_eoh_data")
    os.makedirs(save_dir, exist_ok=True)  # 创建目录（如果不存在）

    save_path = os.path.join(save_dir, "data_for_eoh.npz")
    np.savez_compressed(save_path,
                        best_paths=np.array(best_paths, dtype=object),
                        coordinates=np.array(coordinates, dtype=object))
    print(f"✅ 已保存所有 best_paths 和 coordinates 到 {save_path}")
