class GetPrompts():
    def __init__(self):
        self.prompt_task = (
            "You are designing a strategy to repair sub-optimal TSP solutions. "
            "The TSP tour has been perturbed by breaking it into subpaths. "
            "Your goal is to generate two lists of integers: `length_all` and `first_index_all`, "
            "which define the start index and length of each broken subpath. "
            "These subpaths will then be repaired by a deep learning model. "
            "Design a novel and effective parameter generation algorithm to minimize the gap "
            "between the repaired solution and the optimal TSP solution."
        )

        self.prompt_func_name = "generate_params"
        self.prompt_func_inputs = ["problem_size", "budget"]
        self.prompt_func_outputs = ["length_all", "first_index_all"]

        self.prompt_inout_inf = (
            "'budget' represents the number of repair iterations.\n"
            "`length_all` and `first_index_all` are lists of integers of the same length, "
            "and this length must be equal to the budget.\n"
            "`length_all[i]` specifies the length of the i-th subpath to be broken, "
            "and `first_index_all[i]` specifies its starting index in the tour."
        )

        self.prompt_other_inf = (
            "`length_all[i]` must be between 4 and the smaller of `problem_size` and 1000; any value outside this range will be rejected."
            "`first_index_all[i]` should be a valid starting index within the TSP tour length. "
            "Both lists must be integers."
        )

    def get_task(self):
        return self.prompt_task

    def get_func_name(self):
        return self.prompt_func_name

    def get_func_inputs(self):
        return self.prompt_func_inputs

    def get_func_outputs(self):
        return self.prompt_func_outputs

    def get_inout_inf(self):
        return self.prompt_inout_inf

    def get_other_inf(self):
        return self.prompt_other_inf


if __name__ == "__main__":
    getprompts = GetPrompts()
    print(getprompts.get_task())
