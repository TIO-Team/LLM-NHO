# from machinelearning import *
# from mathematics import *
# from optimization import *
# from physics import *
class Probs():
    def __init__(self,paras):

        if not isinstance(paras.problem, str):
            self.prob = paras.problem
            print("- Prob local loaded ")
        elif paras.problem == "tsp_construct":
            from .optimization.tsp_greedy import run
            self.prob = run.TSPCONST()
            print("- Prob "+paras.problem+" loaded ")
        elif paras.problem == "bp_online":
            from .optimization.bp_online import run
            self.prob = run.BPONLINE()
            print("- Prob "+paras.problem+" loaded ")
        elif paras.problem == "large_tsp":
            from .optimization.large_tsp import run
            self.prob = run.LARGETSP()
            print("- Prob " + paras.problem + " loaded ")
        elif paras.problem == "improve_tsp":
            from .optimization.improve_tsp import run
            self.prob = run.IMPROVE_TSP()
            print("- Prob " + paras.problem + " loaded ")
        elif paras.problem == "encoder_design":
            from .optimization.encoder_design import run
            self.prob = run.ENCODER_DESIGN()
            print("- Prob " + paras.problem + " loaded ")
        else:
            print("problem "+paras.problem+" not found!")


    def get_problem(self):

        return self.prob
