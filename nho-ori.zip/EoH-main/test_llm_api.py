import requests
import json

# === 配置区域 ===
api_url = "https://api.chatanywhere.tech/v1/chat/completions"
api_key = "sk-FCip3RKWiNYXPRCFyx7fdBXlfpnl4CpD06vMf0xeCCmepAou"  # <-- 替换成你的 key
model_name = "gpt-3.5-turbo"

# === 请求数据 ===
headers = {
    "Content-Type": "application/json_2opt",
    "Authorization": f"Bearer {api_key}"
}

payload = {
    "model": model_name,
    "messages": [
        {"role": "user", "content": "请用一句话介绍你自己。"}
    ],
    "temperature": 0.7
}

# === 发起请求 ===
try:
    response = requests.post(api_url, headers=headers, json=payload, timeout=15)
    response.raise_for_status()
    result = response.json()
    print("✅ LLM 响应正常：")
    print(json.dumps(result, indent=2, ensure_ascii=False))

    # 提取回复内容
    content = result['choices'][0]['message']['content']
    print("\n🎯 提取的回答内容：")
    print(content)

except Exception as e:
    print("❌ LLM 请求失败：", e)
